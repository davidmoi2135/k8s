export class ProductCategory {

    //names match with the data that is passed by the spring boot
    constructor(public id: string,
                public categoryName: string){}
}
