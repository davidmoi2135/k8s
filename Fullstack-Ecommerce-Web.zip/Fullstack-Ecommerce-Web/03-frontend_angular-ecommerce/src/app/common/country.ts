export class Country {

    id:number = 0;
    code: string = "";
    name:string = "";
}
