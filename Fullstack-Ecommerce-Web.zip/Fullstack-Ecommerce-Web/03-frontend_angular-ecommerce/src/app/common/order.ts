export class Order {

  public totalQuantity: number | undefined
  public totalPrice: number | undefined

  constructor() {}

}
