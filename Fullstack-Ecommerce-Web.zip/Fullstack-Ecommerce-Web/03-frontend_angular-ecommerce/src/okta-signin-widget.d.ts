declare module '@okta/okta-signin-widget';
