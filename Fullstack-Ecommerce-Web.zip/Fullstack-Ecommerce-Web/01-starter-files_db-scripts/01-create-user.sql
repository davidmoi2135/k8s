CREATE USER 'ecommerceapp'@'%' IDENTIFIED BY 'StrongPa55WorD';

GRANT ALL PRIVILEGES ON * . * TO 'ecommerceapp'@'%';